function efficacyLost(){
	var objAuthor = document.getElementById("author").value;			
	var objTitle = document.getElementById("title").value;
	var objWriteTime = document.getElementById("writeTime").value;
	var objTextContent = document.getElementsByClassName("textContent");
	if(objAuthor.length==0||objTitle.length==0||objWriteTime.length==0||objTextContent.length==0){
		alert("作者，标题，编写时间，内容均不可为空")
		document.getElementById("but").disabled =true;
	}
}