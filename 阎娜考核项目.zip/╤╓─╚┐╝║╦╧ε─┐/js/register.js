function testTel() {
	var tel = document.getElementById("telphone").value;
	var reg1 = new RegExp(/^1[3-9][0-9]{9}$/);
	var telTrue = reg1.test(tel);

	if(telTrue == false) {
		document.getElementById("telWrong").style.cssText = "display:inline-block;";
	} else {
		document.getElementById("telWrong").style.cssText = "display:none;";
	}
	return telTrue;
}

function testPass() {
	var pass = document.getElementById("password").value;
	var reg2 = new RegExp(/(^[a-zA-Z])([a-zA-Z0-9_]{7,15}$)/);
	var passTrue = reg2.test(pass);

	if(passTrue == false) {
		document.getElementById("passWrong").style.cssText = "display:inline-block;";
	} else {
		document.getElementById("passWrong").style.cssText = "display:none;";

	}
	console.log(telTrue);
	return passTrue;
}

function testPassAgain() {
	var pass = document.getElementById("password").value;
	var passAgain = document.getElementById("passwordAgain").value;
    var passAgainTrue = pass.length != 0 && pass == passAgain;
    console.log(passTrue);
	if(passAgainTrue = true) {
		document.getElementById("passAgainWrong").style.cssText = "display:none;";
	} else {
		document.getElementById("passAgainWrong").style.cssText = "display:inline-block;";
	}
	return passAgainTrue;

}

function testEmail() {
	var ema = document.getElementById("email").value;
	var reg3 = new RegExp(/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/);
	var emaTrue = reg3.test(ema);

	if(emaTrue == false) {
		document.getElementById("emailWrong").style.cssText = "display:inline-block;";
	} else {
		document.getElementById("emailWrong").style.cssText = "display:none;";
	}
	return emaTrue;
}

function efficacyLost(){
	if(telTrue==flase||passTrue==false||passAgainTrue==false||emaTrue==false){
		document.getElementById("signIn").disabled =true;
	}
}
