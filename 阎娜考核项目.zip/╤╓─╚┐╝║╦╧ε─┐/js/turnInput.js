function turnInput() {
	var oTurnInput = document.getElementById("turnInput").value;
	console.log(oTurnInput);
	var inputNumber = parseInt(oTurnInput);
	var turnButtonId = document.getElementById("turnButton");
	if(inputNumber>=1&&inputNumber<=3){
		turnButtonId.innerHTML = "<a href='news" + (inputNumber) + ".html'>跳转</a>";
	}
	else{
		alert("查无此页");
	}
	
}