	function testTel(){
				var reg1 = new RegExp(/^1[3-9][0-9]{9}$/);
				var tel = document.getElementById("telphone").value; 
				var telTrue = reg1.test(tel);
				
			    if(telTrue==false){
			    	document.getElementById("telWrong").style.cssText="visibility: visible;";
			    }
			    else{
			    	document.getElementById("telWrong").style.cssText="visibility: hidden;";
			    }
			}
			function testPass(){
				var reg2 = new RegExp(/(^[a-zA-Z])([a-zA-Z0-9_]{4,15}$)/);
				var pass = document.getElementById("password").value;
				var passTrue = reg2.test(passTrue);
				if(passTrue==false){
					document.getElementById("passWrong").style.cssText="visibility: visible;";
					
				}
				else{
			    	document.getElementById("passWrong").style.cssText="visibility: hidden;";
			    	
			   }
			}