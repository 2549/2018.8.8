			function turnPages(){
				var numPages = 3;
				var pageaUrl = window.location.href;
				console.log(pageaUrl);
				var x = pageaUrl.lastIndexOf("/");
				var y = pageaUrl.lastIndexOf("?")
				 if(y!=-1){
                	pageaUrl = pageaUrl.substring(x+1,y);
                }
				else if(y==-1){
					pageaUrl = pageaUrl.substring(x+1);
                }
				console.log(x);
				console.log(y);
				console.log(pageaUrl);
				var reg = /^(news)([0-9]{1,2}).(html)$/;
				reg.exec(pageaUrl);
				var page = RegExp.$2;
				console.log(page);
                page = parseInt(page);
//              if(page==1){
//              	document.getElementById("next").inninnerHTML="<a href = 'a"+(page)+".html'>下一篇</a>"
//              }
               var nextId = document.getElementById("next");
               var nextId = document.getElementById("next");
               var preId = document.getElementById("pre")
               if(page==1){
               	
               	nextId.innerHTML = "<a href='news"+(page+1)+".html'>下一篇</a>";
               }
               else if(page==3){
               	preId.innerHTML = "<a href='news"+(page-1)+".html'>上一篇</a>";
               }
               else if(page>1&&page<3){
               	nextId.innerHTML = "<a href='news"+(page+1)+".html'>下一篇</a>";
               	preId.innerHTML = "<a href='news"+(page-1)+".html'>上一篇</a>";
               }
               
			}
			