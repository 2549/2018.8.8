//点击游客或管理者，跳转到小界面
function logonOpen() {
	var oLogon = document.getElementsByClassName("logon");
	var oAll = document.getElementsByClassName("all");
	oLogon[0].style.cssText = 'display: block;';
	oAll[0].style.cssText = 'display: block;';

}

//点击小界面的叉号,关闭小界面
function logonClose() {
	var oLogon = document.getElementsByClassName("logon");
	var oAll = document.getElementsByClassName("all");
	oLogon[0].style.cssText = 'display: none;';
	oAll[0].style.cssText = 'display: none;';
}